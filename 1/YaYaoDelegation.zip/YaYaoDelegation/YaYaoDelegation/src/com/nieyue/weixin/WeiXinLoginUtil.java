package com.nieyue.weixin;
/**
 * 微信登录
 * @author yy
 *
 */
public class WeiXinLoginUtil {
}
