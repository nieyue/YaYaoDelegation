package com.nieyue.test;

import java.util.UUID;

public class Test5 {
	public static void main(String[] args) {
		System.out.println(UUID.randomUUID().toString().replace("-",""));
	System.out.println((int)(Math.random()*9000+1000));
		
	}
}
