package com.nieyue.comments;

import com.fasterxml.jackson.databind.util.RootNameLookup;

public class MyDefaultSerializerProvider extends RootNameLookup{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
}
