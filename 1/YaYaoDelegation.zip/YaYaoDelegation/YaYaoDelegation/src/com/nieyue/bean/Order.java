package com.nieyue.bean;

public class Order {
	private Integer orderId;

	public int getFeeAmount() {
		// TODO Auto-generated method stub
		return 1;
	}

	public String getOrderCode() {
		// TODO Auto-generated method stub
		return "23134";
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}



}
