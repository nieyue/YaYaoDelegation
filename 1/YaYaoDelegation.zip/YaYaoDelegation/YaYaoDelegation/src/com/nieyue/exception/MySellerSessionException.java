package com.nieyue.exception;

import javax.servlet.ServletException;



public class MySellerSessionException extends ServletException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
}
