package com.nieyue.quartz;

public class MyJob {
	public void dowork() {
		System.out.println("dowork");
		
	}
	public void dowork2() {
		System.out.println("dowork2");
		
	}
}
